# chemlab warehouse - data report

Generated 2026-09-21 05:52Z by `scripts/build_warehouse.py`. Every number below was produced by that script, not typed.

## Size
- **species**: 582
- **species verified against pubchem**: 251
- **reactions**: 424
- **reactions balanced equations**: 207
- **reactions process records**: 217
- **pinned equations**: 123
- **elements**: 118
- **ksp**: 76
- **pka**: 53
- **e0 couples**: 87
- **thermo species**: 186
- **glassware**: 60
- **techniques**: 15
- **displacement predictions**: 703
- **solubility entries derived**: 76
- **lab tables**: 15
- **mixing rules**: 23
- **refusal topics**: 8

## Provenance
Every numeric field is an object `{value, units, source, ref_id, confidence}`. `confidence` is one of `high` (curated from CRC-class reference), `med` (single-source or annotation-derived), `approx` (order-of-magnitude only - the app must show it as such) or `null` with a `missing` reason. Nothing is interpolated: a gap stays a gap.

### How the numbers split
- computed by the kernel (molar mass, balancing, ΔH, solubility, pH, EMF): **1732**
- curated (CRC 97th): **716**
- curated: reference tables (Ksp/pKa/E0/thermo): **445**
- PubChem (verified CID only): **207**
- PubChem GHS annotations: **188**
- phase-transition table, mendeleev 1.3.0 (MIT), data as cited below: **128**
- CRC Handbook 95th ed. (Haynes 2014); enwiki:1039678864 via mendeleev 1.3.0 (MIT), data as cited below: **87**
- PubChem annotation (CAMEO Chemicals): **83**
- PubChem annotation (Hazardous Substances Data Bank (HSDB)): **78**
- Periodic-Table-JSON (Bowserinator), CC BY-SA 3.0: **27**
- PubChem annotation (PAC Chemical Database, U.S. Department of Energy): **10**
- PubChem annotation (ILO-WHO International Chemical Safety Cards (ICSCs)): **5**
- PubChem annotation (Human Metabolome Database (HMDB)): **1**
- PubChem annotation (Occupational Safety and Health Administration (OSHA)): **1**
- PubChem annotation (DrugBank): **1**
- PubChem annotation (Haz-Map, Information on Hazardous Chemicals and Occupational Diseases): **1**
- PubChem annotation (EU Food Improvement Agents): **1**

### What kind of record each species is

- `species`: 492 - a real substance with a formula the kernel can weigh
- `aqueous_ion`: 53 - created by the build so a net-ionic equation resolves; it has a charge and a computed mass, but it is not a bottle
- `mixture`: 19 - several components with no fixed ratio (petroleum ether, solder, soda lime, bleach): no single molar mass, so the app must not run stoichiometry on it
- `alias`: 10 - a pointer row that exists so a name or an old id still resolves; it carries `alias_of`, and the app should redirect to that record
- `note`: 6 - a record whose only job is to carry a safety or apparatus note (e.g. that no cyanide bottle exists here); never selectable as a reagent
- `polymer`: 2 - a macromolecule (cellulose, casein, starch): there is no molecule to count

## Validation the build performs
- equations failing the atom/charge ledger: **0** (ok)
- equations where the solver disagrees with curation: **0** (ok)
- unresolved species tokens in equations: **0** (ok)
- species with a malformed CAS: **1** (ATTENTION)
- equations the solver could not re-derive, kept as pinned: **1** (by design)
- reaction records typed process (no equation, by design): **217** (by design)
- species with no strict formula (mixture/polymer/alias/note): **90** (by design)
- build warnings: **91** (by design)

`balance_check` runs the atom/charge ledger over the equation string as it will be shown; `solver` independently re-balances the skeleton and compares coefficients, so an equation is either solver-derived or explicitly `pinned` by curation. `pinned` records carry coefficients a human verified (typically a redox or organic equation where more than one balance exists, e.g. iodoform) and they are still checked for atom and charge conservation.

`thermo_derived` computes dH for every complete equation from the formation table; where the curated dH (in `extras`) disagrees by more than 3 kJ the build warns, so the two sources audit each other.

## ΔH cross-check
- complete equations with all dHf present: **111** of **207**
- curated and derived values agree within 3 kJ: **13**
- disagreements that need curation attention: **0**
- flagged only because the equation states no phase (basis caveat, not an error): **12**
- no derived value possible (a term has no dHf): **96**

## Coverage and honesty limits
- molar mass: 492/492 (100 %) - excluding the 90 mixture/alias/ion rows, which have no single formula to weigh
- aqueous solubility: 195/582 (34 %)
- melting point: 356/582 (61 %)
- boiling point: 260/582 (45 %)
- density: 335/582 (58 %)
- CAS number: 413/492 (84 %) - excluding the 90 mixture/alias/ion rows, which have no single formula to weigh
- GHS block (signal word or H-codes): 188/582 (32 %)
- SMILES (PubChem, CID formula+MW verified): 207/251 (82 %) - of the 251 records whose PubChem CID was verified by formula and molar mass
- InChIKey: 207/251 (82 %) - of the 251 records whose PubChem CID was verified by formula and molar mass
- a teaching note: 499/582 (86 %)
- reactions with a curated timescale: 97/424
- reactions with a curated hazard level: 79/424
- reactions with apparatus named: 141/424
- SMILES coverage is capped by PubChem name resolution, not by the dataset's ambition; unresolved records keep `smiles: null` and the app shows a 2D formula box instead of nothing.

## Known data defects surfaced by the build (kept, not hidden)

Two classes deserve a note because they are *findings*, not mistakes: a formula that is a mixture by nature (petroleum ether, litmus, 'mixture') has no single molar mass, so it is typed `mixture` and left unweighed; and a curated CAS number that PubChem's own registry list does not contain is kept with a `cas_conflict` object on the record - the app should show both numbers and say which came from where, rather than silently prefer one source.
- species butan1ol: curated CAS 71-36-3 is not among PubChem's ['60-29-7']
- species petrolether: formula 'C5H12mix' typed as mixture
- species methyleorange: curated CAS 547-32-0 is not among PubChem's ['547-58-0']
- species litmus: formula 'mixture' typed as mixture
- species universalind: formula 'mixture' typed as mixture
- species eriochrblackt: curated CAS 17659-98-2 is not among PubChem's ['1787-61-7']
- species diphenylamine: curated CAS 120-71-2 is not among PubChem's ['122-39-4', '68442-68-2']
- species potassiumiodidest: formula 'mixture' typed as mixture
- species baho2: curated CAS 4022-23-9 is not among PubChem's ['17194-00-2']
- species nh4oh: curated CAS 1336-21-6 is not among PubChem's ['7664-41-7']
- species feoh2: curated CAS 12068-43-2 is not among PubChem's ['18624-44-7']
- species znoh2: curated CAS 19782-30-0 is not among PubChem's ['20427-58-1']
- species co2oh: curated CAS 12030-29-4 is not among PubChem's ['12672-51-4', '21041-93-0']
- species na2so4: curated CAS 7757-82-6 is not among PubChem's ['13759-07-4', '15124-09-1', '68081-98-1', '68140-10-3', '68412-82-8', '7557-82-6']
- species na2sx: formula 'Na2Sx' typed as mixture
- species na2s2o3: curated CAS 10102-17-7 is not among PubChem's ['7772-98-7']
- species naclo3: curated CAS 7789-09-5 is not among PubChem's ['7775-09-9', '9011-70-5']
- species kclo3: curated CAS 3811-4-9 is not among PubChem's ['3811-04-9']
- species pbno2: curated CAS 10294-40-3 is not among PubChem's ['10101-63-0']
- species cucl2: curated CAS 10125-13-0 is not among PubChem's ['1344-67-8', '7447-39-4']
- species cuno3aq: curated CAS 10031-43-3 is not among PubChem's ['10402-29-6', '3251-23-8']
- species cuo: curated CAS 1317-36-8 is not among PubChem's ['1317-38-0', '1344-70-3']
- species cu2o: curated CAS 1310-42-5 is not among PubChem's ['1317-39-1']
- species znso4: curated CAS 7446-20-0 is not among PubChem's ['7733-02-0']
- species feso4: curated CAS 7782-63-0 is not among PubChem's ['16547-58-3', '7720-78-7', '7782-63-0 (heptahydrate)']
- species fecl2: curated CAS 13478-10-9 is not among PubChem's ['7758-94-3']
- species feno3_3: curated CAS 7782-61-8 is not among PubChem's ['10421-48-4']
- species kalsulfate: curated CAS 7784-24-9 is not among PubChem's ['10043-67-1']
- species mgno3: curated CAS 10034-88-5 is not among PubChem's ['10377-60-3']
- species mgso4: curated CAS 10034-99-8 is not among PubChem's ['18939-43-0', '68081-97-0', '7487-88-9']
- species plastics: formula 'mix' typed as mixture
- species solsulph: formula 'mix' typed as mixture
- species na2o2: curated CAS 1313-60-2 is not among PubChem's ['1313-60-6']
- species nabio3aq: curated CAS 12233-26-2 is not among PubChem's ['12232-99-4']
- species agno2: curated CAS 7782-00-5 is not among PubChem's ['7783-99-5']
- species cuno3s: curated CAS 10031-43-3 is not among PubChem's ['10402-29-6', '3251-23-8']
- species coso4: curated CAS 10026-24-1 is not among PubChem's ['10124-43-3']
- species cocl2: curated CAS 7791-13-1 is not among PubChem's ['1332-82-7', '7646-79-9']
- species niso4: curated CAS 10101-98-1 is not among PubChem's ['10101-97-0', '7786-81-4']
- species mnso4: curated CAS 10034-96-5 is not among PubChem's ['10124-55-7', '7785-87-7']
- species cunoh: curated CAS 7789-45-9 is not among PubChem's ['10124-44-4', '18939-61-2', '7758-98-7']
- species feammo: formula 'x' typed as alias
- species pbio: curated CAS 1317-36-2 is not among PubChem's ['12059-89-1', '1314-27-8', '1317-36-8', '79120-33-5']
- species pbo2: curated CAS 1309-60-6 is not among PubChem's ['1309-60-0']
- species sncl2: curated CAS 10025-69-1 is not among PubChem's ['7772-99-8']
- species cds: curated CAS 1306-19-0 is not among PubChem's ['1306-23-6', '68859-25-6']
- species mns: curated CAS 1344-43-0 is not among PubChem's ['12687-82-0']
- species cus: curated CAS 20548-53-2 is not among PubChem's ['1317-40-4', '19138-68-2']
- species pbcro4solid: formula 'x' typed as alias
- species bacl2: curated CAS 10326-27-9 is not among PubChem's ['10361-37-2']
- species h3bo3: curated CAS 10043-80-6 is not among PubChem's ['10043-35-3', '11113-50-1', '13813-79-1']
- species citratebuffer: formula 'mix' typed as mixture
- species na2c2o4: malformed CAS '127-09-341-3' and no PubChem record to fix it
- species cocl2hex: alias points at 'cocl2a cobalt chloride paper', which is not a record
- species mgmix: formula 'mix' typed as mixture
- species hgo2: formula 'x' typed as alias
- species sodalime: formula 'mix' typed as mixture
- species asbestossim: formula 'cellulose' typed as polymer
- species rbcl: curated CAS 7787-18-0 is not among PubChem's ['7791-11-9']
- species srno3: curated CAS 10042-76-5 is not among PubChem's ['10042-76-9']
- species cuno3solid: formula 'x' typed as alias
- species k4fe_cn6: formula 'x' typed as alias
- species h2s_gen: formula 'mix' typed as note
- species al2so4_18: curated CAS 1797-98-4 is not among PubChem's ['10043-01-3', '10124-29-5', '55892-56-3']
- species naalo2: curated CAS 11092-32-3 is not among PubChem's ['11138-49-1', '1302-42-7']
- species nacn_free_note: formula 'x' typed as note
- species h2sfire: formula 'CO+H2' typed as mixture
- species ethyne: curated CAS 74-86-2 is not among PubChem's ['74-85-1', '87701-65-3']
- species h2gas_safety: formula 'x' typed as note
- species fe_powder: formula 'x' typed as alias
- species nicr: formula 'Ni+Cr' typed as mixture
- species solder: formula 'mix' typed as mixture
- species fusewire: formula 'mix' typed as mixture
- species lactose: curated CAS 5989-81-1 is not among PubChem's ['5965-66-2', '63-42-3']
- species protein_casein: formula 'protein' typed as polymer
- species ester_ethylacetate: formula 'x' typed as alias
- species soapsolution: formula 'mix' typed as mixture
- species saccharosetest: formula 'x' typed as alias
- species citrusjuice: formula 'mix' typed as mixture
- species baking_powder: formula 'mix' typed as mixture
- ... and 11 more

## The periodic layer: every element, and what happens when two of them meet

Three things had to be true before the app could offer 'pick any element, mix it, see everything'. They are, and each is a separate piece of data.

**Every element is a record.** An element row carries: mass with its CIAAW uncertainty, category, phase at 298 K, group/period/block, electron configuration and shell counts, Pauling and Allen electronegativity, electron affinity, the ionisation series, atomic / covalent / metallic / van der Waals radii, ionic radii per coordination number, density, molar and specific heat capacity, thermal conductivity, lattice structure and constant, melting and boiling point, fusion and vaporisation enthalpy, crust and sea abundance, common and extended oxidation states, the natural isotopes with abundances and spins, the element's CAS number, appearance, a summary, where it comes from and what it is used for, and a swatch colour for the interface. Each number keeps its own citation.

| element field | elements with a value |
|---|---|
| melting point | 109/118 |
| boiling point | 107/118 |
| density | 118/118 |
| heat capacity (molar) | 85/118 |
| fusion enthalpy | 75/118 |
| electronegativity | 85/118 |
| atomic radius | 90/118 |
| electron affinity | 77/118 |
| ionisation energies | 104/118 |
| common oxidation states | 100/118 |
| ionic radii | 98/118 |
| natural isotopes | 84/118 |
| CAS number | 118/118 |
| crust abundance | 88/118 |
| a summary paragraph | 118/118 |

**Every element has a bottle.** 87 elements had no record at all, so the build generated a standard-state shelf record for each one - formula from the phase (H2, O2, Br2, S8 as written, metals as the symbol), molar mass computed, and every physical property the cited table gives for that element. 118/118 elements now resolve to at least one species. Radioactive and synthetic elements are marked `not_a_shelf_reagent` so the app can show the information without letting anybody put them in a beaker.

**Every element pair has an answer.** 9410 rows, in `data/combinations.json.gz` and the SQLite table `combination`, one per formula the valence rules allow for a pair of elements, plus an explicit row for the pairs that give nothing:

| status | rows | what the app may say |
|---|---|---|
| `verified` | 72 | the formula is a substance in this dataset: show its measured properties by following `species_id`, and the preparation by following `reaction_ids` |
| `empirical` | 3 | same atoms in a different multiple (P2O5 for P4O10): properties come from that record and both formulas are shown |
| `predicted` | 5789 | the valences allow the formula and nothing more is known: mass, electronegativity difference and Pauling ionic character are arithmetic, and 156 rows also carry an emf, log K and a free energy derived from the electrode table - no melting point, no colour, no yield, ever |
| `none` | 3546 | the pair gives no binary compound in this model, with the reason (noble gas; two metals, so an alloy has no formula; no valence pair that balances) |

9 of those rows point at a reaction already in the dataset, which is the honest answer to 'what happens if I mix these two': if an equation exists it is shown, and only its own equation.

**Mixing two solutions** is a different question and has its own table: `tables.precipitation_matrix`, 380 cation-anion pairs of the ions this shelf can actually supply. 50 are decided by a measured solubility product (with the molar and g/L solubility computed from it), 256 by the curated solubility rules and labelled as a rule, 19 by an acid-base rule read off `tables.pka` (Kw for H+ + OH-), 55 say 'not covered' rather than guess. 135 of them give a precipitate.

## What the app can show for one substance

The bottle sheet is not a fixed list: it shows the fields that exist and says why the rest are blank. This is the whole inventory of what a record may carry.

| field | species | where it comes from |
|---|---|---|
| `id` | 582/582 | the record key, unique |
| `name` | 582/582 | curated |
| `formula` | 545/582 | as written, then Hill-normalised by the kernel |
| `state` | 527/582 | curated: s / l / g / aq |
| `kind` | 582/582 | species / aqueous_ion / mixture / polymer / alias / note |
| `elements` | 492/582 | counted from the formula by the kernel |
| `oxidation_states` | 348/582 | assigned by the textbook rules (kernel); per element |
| `molar_mass` | 582/582 | computed from CIAAW atomic weights |
| `colour_description` | 440/582 | curated wording, kept verbatim |
| `colour_hex` | 440/582 | resolved through tables.colour_map |
| `odour` | 34/582 | curated |
| `props_mp` | 529/582 | CRC 97th, else a PubChem annotation, else null with a reason |
| `props_bp` | 529/582 | as melting point |
| `props_den` | 529/582 | as melting point |
| `props_sol` | 195/582 | curated solubility in water |
| `heat_capacity_molar` | 54/582 | element table (only on generated element bottles) |
| `fusion_heat` | 47/582 | element table: q = n x this, for melt/freeze maths |
| `vol` | 36/582 | volatile / hygroscopic / deliquescent flags |
| `dhf` | 1/582 | standard enthalpy of formation, phase-aware |
| `props_ka` | 36/582 | from tables.pka where the species is itself the acid |
| `ghs` | 495/582 | PubChem GHS block: signal word, H and P statements, pictograms, NFPA |
| `hazard_score` | 442/582 | curated 0-5 teaching hazard, not a legal classification |
| `cas` | 414/582 | curated, cross-checked against PubChem's registry list |
| `flame` | 8/582 | flame colour for the wire-loop test |
| `pubchem` | 251/582 | CID-verified SMILES, InChIKey, XLogP, TPSA, H-bond counts |
| `note` | 499/582 | curated: what to look for, what it is used for, the caveat |
| `stock` | 14/582 | the stock-bottle entry: concentration, purity, container |
| `forms` | 10/582 | other records of the same substance (anhydrous/hydrate/solution) |
| `reacts` | 4/582 | reaction ids this species appears in |
| `alias_of` | 12/582 | for alias rows: the record to show instead |

## Refusals (the guard rail the app enforces from data)
- **synthesis of explosives** - Blocked. Not because a phone can't display it, but because the only thing an app adds over a textbook here is a step-by-step recipe with quantities and a 'run again' button. *Shown instead:* The reaction itself, its energetics and its accident history are in the safety records - that's the teachable part.
- **cyanide chemistry** - Blocked. Acidifying any cyanide salt in an unventilated room is a death, and home users do have 'silver dip' and 'gold dip' in a drawer. *Shown instead:* The cyanide-ion test chemistry (Prussian blue) is shown descriptively as reference with the hazard numbers.
- **controlled-substance synthesis** - Blocked. *Shown instead:* Pharmacology and detection chemistry are described as data, not as a procedure.
- **mustard gas / nerve-agent chemistry** - Blocked completely. *Shown instead:* Not a school experiment, not a home experiment, not a thing an app should help with even in a 'theoretical' mode.
- **mercury and lead preparations** - Blocked at quantity; the properties/hazard pages exist. *Shown instead:* Cumulative poisons, and the exposure route people forget is vapour and dust, not skin.
- **white phosphorus and its compounds** - Blocked. *Shown instead:* Red phosphorus is present as data with the oxidiser warning.
- **carbon monoxide in an enclosed space** - Blocked; CO from a formic-acid/S-h2so4 train is a standard demo but not in a bedroom. *Shown instead:* The gas tests and the toxicology are in the record.
- **hydrogen in a sealed vessel with a flame** - Warn + require an open-vessel choice. *Shown instead:* The squeaky pop is a detonation in miniature; the app should say so rather than pretend otherwise.

## Safety roll-up
- hard-stopped reactions: 2 (``app_bleach_acid_warning, app_bleach_ammonia``)
- restricted/display-only: 3
- needing a fume hood: 4
- hazard-score-5 species: 1
- species whose GHS block contains a fatal/corrosive/oxidising statement: 43

an app-level guard must be: refuse if the reaction is in reactions_hard_stopped, or if a reagent is in species_hazard5 and the user has no hood; warn otherwise. The refusal text comes from lab.refusals, so the app never argues with the user - it quotes.

## Licences
- curated reaction/species/reference tables: CC0-1.0 (dedicated to the public domain)
- CRC Handbook of Chemistry and Physics, 97th ed.: copyrighted - only individual numeric values are used, which are not themselves copyrightable
- IUPAC/CIAAW standard atomic weights: CC BY-NC-SA 4.0 for the table; the values are data
- PubChem (NLM): PubChem records are largely public domain; individual annotated values cite their own source (CRC, NTP, ILO ICSC, ECHA)
- Bowserinator Periodic-Table-JSON: CC BY-SA 3.0
- mendeleev 1.3.0 (vendored slice, MIT): MIT (c) Klaus Lida, David Zienkiewicz
- OSHA HazCom 29 CFR 1910.1200 / UNECE GHS Rev.9: US government work / UNECE - reproduction permitted with acknowledgement
- NFPA 704: NFPA is a trademark; ratings are reproduced as data from PubChem's ICSC/CRC entries, not from an NFPA table

## SQLite
`data/chemlab.db` - see `spec/DATA_SCHEMA.md`. 24 tables; every row of the JSON above is in it, and the counts the build verified against its own source: combination=9410, curriculum=43, displacement=703, e0=87, element=118, glassware=192, h_code=1582, indicator=20, isotope=322, kit=92, ksp=76, meta=7, mixing_rule=23, observation=1332, p_code=5194, pka=71, precip=380, prop=1782, reaction=424, refusal=8, species=582, technique=15, term=1662, thermo=249.

